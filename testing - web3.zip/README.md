# react-tezos-template

Live Demo: https://scaffold-tez.vercel.app/

## Setup
Clone and install dependencies
```bash
git clone https://github.com/vivekascoder/react-tezos-template
```

Install dependencies
```bash
cd react-tezos-template
yarn install
```


## How to run the project
```bash
yarn start
```
"# web3" 
"# web3-test" 
