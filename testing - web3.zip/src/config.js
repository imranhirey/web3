const config = {
  contractAddress: "KT1N11kC9LuDnhAWV4r7fr3dFfDUB3HXwkix",
};

export default config;
